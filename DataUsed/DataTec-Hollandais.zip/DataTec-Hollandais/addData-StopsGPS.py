import csv
import MySQLdb
#correction DB:  delete from  Tec.stops_gps where stop_lat='';

mydb = MySQLdb.connect(host='localhost',
    user='root',
    passwd='',
    db='Tec')
cursor = mydb.cursor()

csv_data = csv.reader(file('stops.txt'))
for row in csv_data:
    sql = 'INSERT INTO stops_gps(stop_id, stop_name, stop_lat, stop_lon) VALUES({0},"{1}","{2}","{3}")'.format(row[0],row[2],row[3],row[4])
    print sql
    cursor.execute(sql)
#close the connection to the database.
mydb.commit()
cursor.close()
print "Done"
